import { useState } from "react";

import ResultsBody from "./components/ResultsBody";
import ResultsHeading from "./components/ResultsHeading";

function ResultsPage() {
  const [selectedTrip, setSelectedTrip] = useState(null);
  const [bookingStep, setBookingStep] = useState(1);

  const handleSelectTrip = (trip) => {
    setSelectedTrip(trip);
    setBookingStep(1);
  };

  return (
    <div>
      {!selectedTrip ? (
        <>
          <ResultsHeading />
          <ResultsBody onSelectTrip={handleSelectTrip} />
        </>
      ) : (
        <div>
          {/* مراحل إتمام الحجز سنبنيها هنا */}
          <p>مرحلة الحجز رقم: {bookingStep}</p>
        </div>
      )}
    </div>
  );
}

export default ResultsPage;
