import { ArrowLeft, Bus, Star } from "lucide-react";

function CompaniesFilter({ companies = [], selectedCompany, onSelectCompany }) {
  return (
    <section>
      <div className="mt-8">
        <div className="mb-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="grid h-[36px] w-[36px] place-items-center rounded-[12px] bg-[var(--soft-teal)] text-[14px] font-black text-[var(--primary)]">
              01
            </span>

            <div>
              <h3 className="text-lg font-black">اختيار شركة النقل</h3>

              <p className="m-0 text-xs text-[var(--muted)]">
                حدد الشركة اللي بتفضّلها، ومنعرضلك مواعيدها المتاحة.
              </p>
            </div>
          </div>

          <span className="hidden items-center gap-2 text-xs font-extrabold text-[var(--muted)] sm:flex">
            02 <ArrowLeft size={15} /> اختيار الوقت والمقعد
          </span>
        </div>

        {companies.length > 0 ? (
          <div className="grid grid-cols-2 gap-[11px] sm:grid-cols-3 lg:grid-cols-5">
            {/* All Companies */}
            <button
              type="button"
              onClick={() => onSelectCompany("all")}
              className={`
                flex min-w-0 cursor-pointer flex-col items-center gap-[7px]
                rounded-[13px] border px-[11px] py-[18px]
                transition-all duration-200
                ${
                  selectedCompany === "all"
                    ? "border-[var(--primary)] bg-[var(--soft-teal)]"
                    : "border-[var(--border)] bg-[var(--surface)] hover:border-[var(--primary)]"
                }
              `}
            >
              <Bus size={27} className="text-[var(--primary)]" />

              <h4 className="text-sm font-black">كل الشركات</h4>

              <p className="m-0 text-xs text-[var(--muted)]">قارن الخيارات</p>
            </button>

            {/* Companies */}
            {companies.map((company) => (
              <button
                key={company.id}
                type="button"
                onClick={() => onSelectCompany(company.id)}
                className={`
                  flex min-w-0 cursor-pointer flex-col items-center gap-[7px]
                  rounded-[13px] border px-[11px] py-[18px]
                  transition-all duration-200
                  ${
                    String(selectedCompany) === String(company.id)
                      ? "border-[var(--primary)] bg-[var(--soft-teal)]"
                      : "border-[var(--border)] bg-[var(--surface)] hover:border-[var(--primary)]"
                  }
                `}
              >
                <span className="grid h-[32px] w-[32px] place-items-center rounded-[10px] bg-[var(--soft-teal)] text-sm font-black text-[var(--primary)]">
                  {company.name?.charAt(2)}
                </span>

                <h4 className="text-center text-sm font-black">
                  {company.name.slice(0, -8)}
                </h4>
                <span className="flex items-center gap-[3px] text-xs font-extrabold text-[var(--muted)]">
                  <Star size={15} className="inline-block text-yellow-500" />{" "}
                  4.9
                </span>
              </button>
            ))}
          </div>
        ) : (
          <div className="rounded-xl border border-[var(--border)] p-6 text-center text-sm text-[var(--muted)]">
            لا توجد شركات نقل متاحة.
          </div>
        )}
      </div>
    </section>
  );
}

export default CompaniesFilter;
