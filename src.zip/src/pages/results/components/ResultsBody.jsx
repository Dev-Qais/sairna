import { useState } from "react";

import SearchBox from "../../home/components/SearchBox";

import { useCompanies } from "../../../hooks/companies/useCompanies";
import useTrips from "../../../hooks/trips/useTrips";
import useSearchStore from "../../../store/useSearchStore";

import CompaniesFilter from "../components/body/CompaniesFilter";
import ResultsToolbar from "../components/body/ResultsToolbar";
import ResultsSidebar from "./body/ResultsSidebar";
import TripCard from "./body/TripCard";

function ResultsBody({ onSelectTrip }) {
  // Search data
  const searchData = useSearchStore((state) => state.searchData);

  // Selected company
  const [selectedCompany, setSelectedCompany] = useState("all");

  // Sorting
  const [sortBy, setSortBy] = useState("earliest");

  const [departurePeriod, setDeparturePeriod] = useState("all");

  // Companies
  const {
    data: companies = [],
    isPending: companiesLoading,
    isError: companiesError,
  } = useCompanies();

  // Trips filters
  const tripsFilters = {
    ...searchData,
    ...(selectedCompany !== "all" && {
      companyId: selectedCompany,
    }),
  };

  // Trips
  const {
    data: trips = [],
    isLoading: tripsLoading,
    isError: tripsError,
    error,
  } = useTrips(tripsFilters);

  const { data: allTrips = [], isLoading: allTripsLoading } = useTrips({});

  const getDamascusHour = (departureAt) => {
    return Number(
      new Intl.DateTimeFormat("en-US", {
        hour: "2-digit",
        hourCycle: "h23",
        timeZone: "Asia/Damascus",
      }).format(new Date(departureAt)),
    );
  };

  const filteredTrips = trips.filter((trip) => {
    if (departurePeriod === "all") return true;

    const hour = getDamascusHour(trip.departureAt);

    if (departurePeriod === "morning") {
      return hour < 12;
    }

    if (departurePeriod === "afternoon") {
      return hour >= 12 && hour < 17;
    }

    if (departurePeriod === "evening") {
      return hour >= 17;
    }

    return true;
  });

  // Sort trips
  const sortedTrips = [...filteredTrips].sort((a, b) => {
    if (sortBy === "cheap") {
      return a.price - b.price;
    }

    if (sortBy === "quick") {
      const durationA = new Date(a.arrivalAt) - new Date(a.departureAt);

      const durationB = new Date(b.arrivalAt) - new Date(b.departureAt);

      return durationA - durationB;
    }

    return new Date(a.departureAt) - new Date(b.departureAt);
  });

  console.log("Sorted Trips:", sortedTrips);
  console.log("First Trip:", sortedTrips[0]);

  return (
    <section className="container pb-24">
      {/* Search */}
      <SearchBox showHeader={false} />

      {/* Companies Filter */}
      {companiesLoading ? (
        <p className="mt-8 text-sm text-[var(--muted)]">
          جاري تحميل شركات النقل...
        </p>
      ) : companiesError ? (
        <p className="mt-8 text-sm text-red-500">
          حدث خطأ أثناء تحميل شركات النقل.
        </p>
      ) : (
        <CompaniesFilter
          companies={companies}
          selectedCompany={selectedCompany}
          onSelectCompany={setSelectedCompany}
        />
      )}

      {/* Results Toolbar */}
      <ResultsToolbar
        tripsCount={sortedTrips.length}
        searchData={searchData}
        sortBy={sortBy}
        onSortChange={setSortBy}
      />
      <div className="mt-5 flex flex-col gap-6 lg:flex-row">
        {/* Sidebar */}
        <ResultsSidebar
          companies={companies}
          allTrips={allTrips}
          selectedCompany={selectedCompany}
          onSelectCompany={setSelectedCompany}
          departurePeriod={departurePeriod}
          onSelectDeparturePeriod={setDeparturePeriod}
          onResetFilters={() => {
            setSelectedCompany("all");
            setDeparturePeriod("all");
          }}
        />
        {/* Trips */}
        <div className="flex-1">
          {sortedTrips.map((trip) => (
            <TripCard key={trip.id} trip={trip} onSelectTrip={onSelectTrip} />
          ))}
        </div>
      </div>

      {/* Trips */}
    </section>
  );
}

export default ResultsBody;
