import Header from "../components/shared/Header";
import Footer from "../components/shared/Footer";
import AnnouncementBar from "../components/shared/AnnouncementBar";
import Breadcrumbs from "../components/common/Breadcrumbs";
import { Outlet } from "react-router-dom";
function MainLayout() {
  return (
    <>
      <AnnouncementBar />
      <Header />
      <main>
        <Breadcrumbs />
        <Outlet />
      </main>
      <Footer />
    </>
  );
}

export default MainLayout;
